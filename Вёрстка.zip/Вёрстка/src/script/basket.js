const calucaletTotalTitle = document.querySelector(".basket-info__calculate-title");
const calucaletTotalDropdown = document.querySelector(".basket-info__calculat-content");

if (calucaletTotalTitle) {
    calucaletTotalTitle.addEventListener("click", () => {
        calucaletTotalTitle.classList.toggle("active");
        calucaletTotalDropdown.classList.toggle("active");
    });
}


function recalcTotal() {
    let subtotal = 0;
    document.querySelectorAll('.basket-list__item').forEach(item => {
        const unitPrice = parseFloat(item.getAttribute('data-price')) || 0;
        const count = parseInt(item.querySelector('.product-card-count').value) || 1;
        subtotal += unitPrice * count;
    });

    document.querySelector('.basket-info__pre-total-value').innerText = subtotal;

    let deliveryCost = 0;
    const deliveryRadio = document.querySelector('#delivery');
    if (deliveryRadio && deliveryRadio.checked) {
        deliveryCost = 1500;
    }

    const total = subtotal + deliveryCost;
    document.querySelector('.basket-info__total-price').innerText = total;
}

document.querySelectorAll('.product-card__plus').forEach(plusBtn => {
    plusBtn.addEventListener('click', function () {
        const countControl = this.closest('.product-card__count-control');
        const input = countControl.querySelector('.product-card-count');
        let count = parseInt(input.value) || 0;
        count++;
        input.value = count;

        const basketItem = this.closest('.basket-list__item');
        const unitPrice = parseFloat(basketItem.getAttribute('data-price')) || 0;
        const priceElement = basketItem.querySelector('.basket-item-price-and-count h5');
        priceElement.innerText = (unitPrice * count) + 'p';

        recalcTotal();
    });
});

document.querySelectorAll('.product-card__minus').forEach(minusBtn => {
    minusBtn.addEventListener('click', function () {
        const countControl = this.closest('.product-card__count-control');
        const input = countControl.querySelector('.product-card-count');
        let count = parseInt(input.value) || 0;
        if (count > 1) {
            count--;
            input.value = count;
            const basketItem = this.closest('.basket-list__item');
            const unitPrice = parseFloat(basketItem.getAttribute('data-price')) || 0;
            const priceElement = basketItem.querySelector('.basket-item-price-and-count h5');
            priceElement.innerText = (unitPrice * count) + 'p';

            recalcTotal();
        }
    });
});

document.querySelectorAll('.remove-basket-item').forEach(removeBtn => {
    removeBtn.addEventListener('click', function () {
        const basketItem = this.closest('.basket-list__item');
        basketItem.remove();
        recalcTotal();
    });
});

document.querySelectorAll('input[name="radio-group"]').forEach(radio => {
    radio.addEventListener('change', recalcTotal);
});