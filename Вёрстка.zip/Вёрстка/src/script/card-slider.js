const mainSlider = document.querySelector('.gallery-top');
const thumbSlider = document.querySelector('.gallery-thumbs');

let swiperThumb = new Swiper(thumbSlider, {
    slidesPerView: 'auto',
    spaceBetween: 12,
    slideToClickedSlide: true,
    watchSlidesVisibility: true,
    watchSlidesProgress: true,
    threshold: 10,
    shortSwipes: false
});

let swiperMain = new Swiper(mainSlider, {
    slideToClickedSlide: true,
    thumbs: {
        swiper: swiperThumb,
    },
    keyboard: {
        enabled: true,
        onlyInViewport: false,
    },
    navigation: {
        nextEl: '.detox-product-card-next',
        prevEl: '.detox-product-card-prev',
    },
});

document.querySelectorAll('.dropdown-head').forEach(dh => {
    dh.addEventListener('click', () => {
        dh.closest('.dropdown').classList.toggle('active');
    })
});

const productCard = document.querySelector('.detox-product-card__info');

const priceTotalEl = productCard.querySelector('.product-card__price-total');
const countInput = productCard.querySelector('.product-card-count');
const plusButton = productCard.querySelector('.product-card__plus');
const minusButton = productCard.querySelector('.product-card__minus');

const basePrice = parseFloat(productCard.getAttribute('data-price'));

function updatePrice() {
    const count = parseInt(countInput.value);
    const totalPrice = basePrice * count;
    priceTotalEl.textContent = totalPrice;
}

plusButton.addEventListener('click', function () {
    let currentCount = parseInt(countInput.value);
    currentCount++;
    countInput.value = currentCount;
    updatePrice();
});

minusButton.addEventListener('click', function () {
    let currentCount = parseInt(countInput.value);
    if (currentCount > 1) {
        currentCount--;
        countInput.value = currentCount;
        updatePrice();
    }
});
