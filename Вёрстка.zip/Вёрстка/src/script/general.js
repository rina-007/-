const showPassword = document.querySelectorAll('.show-password');
let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
console.log(showPassword, 'showPassword');

if (showPassword.length) {
    showPassword.forEach(sp => {
        sp.addEventListener('click', () => {
            const loginPhone = sp.closest('.auth-form__input').querySelector('input');
            sp.classList.toggle('show');
            const type = sp.classList.contains('show') ? "text" : "password";
            loginPhone.type = type;
        });        
    });
}

const bannerSlider = new Swiper('.banner-slider', {
    slidesPerView: 1,
    spaceBetween: 200,
    navigation: {
        nextEl: '.banner-next',
        prevEl: '.banner-prev'
    },
    on: {
        init: function () {
            updateSlideInfo(this);
        },
        slideChange: function () {
            updateSlideInfo(this);
        }
    }
});

function updateSlideInfo(swiper) {
    document.querySelector('.current-slide').innerText = swiper.activeIndex + 1;
    document.querySelector('.slide-count').innerText = swiper.slides.length;
}

const reviews = new Swiper('#reviews-slider', {
    slidesPerView: 3,
    spaceBetween: 98,
    navigation: {
        nextEl: '.reviews-next',
        prevEl: '.reviews-prev'
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        576: {
            slidesPerView: 1,
        },
        992: {
            slidesPerView: 2,
        },
        1400: {
            slidesPerView: 3,
        }
    },
});

const stock = new Swiper('#stock-slider', {
    slidesPerView: 3,
    spaceBetween: 17,
    navigation: {
        nextEl: '.stock-next',
        prevEl: '.stock-prev'
    },
    breakpoints: {
        0: {
            slidesPerView: 1,
        },
        576: {
            slidesPerView: 1,
        },
        992: {
            slidesPerView: 2,
        },
        1400: {
            slidesPerView: 3,
        }
    },
});

document.getElementById("burger").addEventListener("click", function () {
    this.classList.toggle("active");
    const menu = document.querySelector('.nav__links');
    const body = document.body;
    if (this.classList.contains('active')) {
        menu.classList.add('active');
        body.style.overflow = 'hidden';
    } else {
        menu.classList.remove('active');
        body.style.overflow = '';
    }
});

if (window.innerWidth < 1024) {
    mobileLinksInit()
}

window.addEventListener('resize', () => {
    mobileLinksInit()
})

const selects = document.querySelectorAll(".select");

selects.forEach(select => {
    const input = select.querySelector("input");
    const dropdown = select.querySelector(".select-dropdown");
    input.addEventListener("click", e => {
        e.stopPropagation();
        console.log(1111);

        dropdown.classList.toggle("active");
    });
    dropdown.querySelectorAll("li").forEach(li => {
        li.addEventListener("click", e => {
            e.stopPropagation();
            input.value = li.textContent;
            dropdown.classList.remove("active");
        });
    });
});

document.addEventListener("click", () => {
    selects.forEach(select => {
        const dropdown = select.querySelector(".select-dropdown");
        dropdown.classList.remove("active");
    });
});

updateCardCount()

function addToCard(tag, event) {
    event.preventDefault();

    const cardItem = tag.closest('.card-item');
    if (!cardItem) return;
    const productId = cardItem.getAttribute('data-product-id');
    let cardItems = JSON.parse(localStorage.getItem('card')) || [];
    let product = cardItems.find(item => item.id === productId);
    if (product) {
        product.quantity++;
    } else {
        product = { id: productId, quantity: 1 };
        cardItems.push(product);
    }
    localStorage.setItem('card', JSON.stringify(cardItems));
    updateCardCount();
}

function addToFavorites(tag, event) {
    event.preventDefault();
    
    const favoriteItem = tag.closest('.card-item');
    if (!favoriteItem) return;
    const productId = favoriteItem.getAttribute('data-product-id');
    let favorites = JSON.parse(localStorage.getItem('favorites')) || [];
    let product = favorites.find(item => item.id === productId);
    if (product) {
        product.quantity++;
    } else {
        product = { id: productId, quantity: 1 };
        favorites.push(product);
    }
    localStorage.setItem('favorites', JSON.stringify(favorites));
    updateFavoriteCount();
}

function updateCardCount() {
    let cardItems = JSON.parse(localStorage.getItem('card')) || [];
    const total = cardItems.reduce((acc, item) => acc + item.quantity, 0);
    document.querySelector('.card-count').textContent = total;
}


function mobileLinksInit() {
    document.querySelectorAll('.nav__links-item').forEach(item => {
        item.addEventListener('click', (event) => {
            event.stopPropagation();

            document.querySelectorAll('.nav__dropdown').forEach(d => {
                if (d !== item.querySelector('.nav__dropdown')) {
                    d.classList.remove('mobile-active');
                }
            });

            const dropdown = item.querySelector('.nav__dropdown');
            if (dropdown) {
                dropdown.classList.toggle('mobile-active');
            }
        });
    });

    document.addEventListener('click', () => {
        document.querySelectorAll('.nav__dropdown').forEach(d => d.classList.remove('mobile-active'));
    });
}

updateFavoriteCount()

function selectProfileLink(that) {
    const profileLinks = document.querySelectorAll('.profile-link');
    const profileLinksContents = document.querySelectorAll('.profile-link__content');
    const dataId = that.dataset.id;
    console.log(dataId);

    profileLinks.forEach(p => p.classList.remove('active'));
    profileLinksContents.forEach(p => p.classList.remove('active'));
    that.classList.add('active');
    document.querySelector(`.${dataId}`).classList.add('active');
}

function updateFavoriteCount() {
    const local = JSON.parse(localStorage.getItem('favorites')) || [];
    const totalCount = local.reduce((sum, item) => sum + item.quantity, 0);
    document.querySelector('.favorite-count').textContent = totalCount;
}