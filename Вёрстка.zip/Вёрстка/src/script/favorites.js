document.querySelectorAll('.favorites__list-item').forEach(item => {
    const productId = item.getAttribute('data-product-id');
    const unitPrice = parseFloat(item.getAttribute('data-price'));
    const input = item.querySelector('.product-card-count');
    const priceTotalElem = item.querySelector('.favorites__price-total');
    let currentItem = favorites.find(fav => fav.id === productId);
    let quantity = currentItem ? currentItem.quantity : 1;
    input.value = quantity;
    priceTotalElem.textContent = unitPrice * quantity;
    const plusBtn = item.querySelector('.product-card__plus');
    const minusBtn = item.querySelector('.product-card__minus');

    plusBtn.addEventListener('click', function () {
        quantity++;
        input.value = quantity;
        priceTotalElem.textContent = unitPrice * quantity;
        if (currentItem) {
            currentItem.quantity = quantity;
        } else {
            currentItem = { id: productId, quantity: quantity };
            favorites.push(currentItem);
        }
        localStorage.setItem('favorites', JSON.stringify(favorites));
        updateFavoriteCount();
    });

    minusBtn.addEventListener('click', function () {
        if (quantity > 1) {
            quantity--;
            input.value = quantity;
            priceTotalElem.textContent = unitPrice * quantity;
            if (currentItem) {
                currentItem.quantity = quantity;
            } else {
                currentItem = { id: productId, quantity: quantity };
                favorites.push(currentItem);
            }
            localStorage.setItem('favorites', JSON.stringify(favorites));
            updateFavoriteCount();
        }
    });
});
